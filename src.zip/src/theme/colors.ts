/** Yellow + white reference theme (Money Manager style). */
export const theme = {
  yellow: '#FFD740',
  yellowDark: '#F5C400',
  white: '#FFFFFF',
  offWhite: '#F8F8F8',
  grayBg: '#EFEFEF',
  text: '#1a1a1a',
  textMuted: '#5c5c5c',
  border: '#E6E6E6',
  black: '#000000',
} as const;
