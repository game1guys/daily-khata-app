import React, { type ComponentType } from 'react';
import { Text, View } from 'react-native';
import {
  Circle,
  Tags,
  UtensilsCrossed,
  ShoppingBag,
  Car,
  Phone,
  GraduationCap,
  Sparkles,
  Dumbbell,
  Users,
  Bus,
  Shirt,
  Wine,
  Cigarette,
  Laptop,
  Plane,
  HeartPulse,
  PawPrint,
  Wrench,
  Home,
  Gift,
  HandHeart,
  Ticket,
  Cookie,
  Baby,
  Apple,
  Wallet,
  TrendingUp,
  Receipt,
  Briefcase,
  Store,
} from 'lucide-react-native';

type IconComp = ComponentType<{ color?: string; size?: number; strokeWidth?: number }>;

const ICON_MAP: Record<string, IconComp> = {
  Circle,
  Utensils: UtensilsCrossed,
  UtensilsCrossed,
  Food: UtensilsCrossed,
  ShoppingBag,
  Shopping: ShoppingBag,
  Car,
  Telephone: Phone,
  Phone,
  Education: GraduationCap,
  GraduationCap,
  Beauty: Sparkles,
  Sparkles,
  Sport: Dumbbell,
  Dumbbell,
  Social: Users,
  Users,
  Transportation: Bus,
  Bus,
  Clothing: Shirt,
  Shirt,
  Wine,
  Cigarette,
  Electronics: Laptop,
  Laptop,
  Travel: Plane,
  Plane,
  Health: HeartPulse,
  HeartPulse,
  Pet: PawPrint,
  PawPrint,
  Repair: Wrench,
  Wrench,
  Housing: Home,
  Home,
  Gift,
  Donate: HandHeart,
  HandHeart,
  Lottery: Ticket,
  Ticket,
  Snacks: Cookie,
  Cookie,
  Baby,
  Fruit: Apple,
  Apple,
  vegetable: Apple,
  Investments: TrendingUp,
  TrendingUp,
  Receipt,
  Bills: Receipt,
  Briefcase,
  Salary: Briefcase,
  Store,
  Business: Store,
  Tags,
};

type Props = {
  iconKey: string | null | undefined;
  color: string;
  size?: number;
};

export function CategoryGlyph({ iconKey, color, size = 22 }: Props) {
  const key = (iconKey || 'Circle').trim();
  if (/[\u{1F300}-\u{1FAFF}]/u.test(key) || key.length <= 4 && /[^\w]/.test(key)) {
    return (
      <Text style={{ fontSize: size }} allowFontScaling={false}>
        {key}
      </Text>
    );
  }
  const normalized = key.replace(/\s+/g, '');
  const Icon = ICON_MAP[normalized] || ICON_MAP[key] || Tags;
  return <Icon color={color} size={size} strokeWidth={2} />;
}

export function CategoryIconCircle({
  iconKey,
  color,
  bg,
  size = 22,
}: Props & { bg: string }) {
  return (
    <View
      style={{
        width: 52,
        height: 52,
        borderRadius: 26,
        backgroundColor: bg,
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <CategoryGlyph iconKey={iconKey} color={color} size={size} />
    </View>
  );
}
