import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';
import { ChevronRight, Settings } from 'lucide-react-native';
import { API_URL } from '../config/api';
import { theme } from '../theme/colors';

export default function ReportsScreen() {
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState({
    totalIncome: 0,
    totalExpense: 0,
    totalSavings: 0,
  });

  const load = async () => {
    try {
      const token = await AsyncStorage.getItem('khata_session');
      if (!token) return;
      const res = await axios.get(`${API_URL}/transactions/summary`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.data?.summary) {
        setSummary({
          totalIncome: res.data.summary.totalIncome,
          totalExpense: res.data.summary.totalExpense,
          totalSavings: res.data.summary.totalSavings,
        });
      }
    } catch (e) {
      console.log('Reports load error', e);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      load();
    }, [])
  );

  const budget = 6000;
  const balance = summary.totalIncome - summary.totalExpense;
  const pct = budget > 0 ? Math.min(100, Math.round((balance / budget) * 1000) / 10) : 0;

  if (loading) {
    return (
      <View style={[styles.root, styles.center]}>
        <ActivityIndicator color={theme.black} size="large" />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.card}>
          <View style={styles.yellowHead}>
            <Text style={styles.headTitle}>Reports</Text>
          </View>
          <View style={styles.whiteBody}>
            <TouchableOpacity style={styles.rowCard} activeOpacity={0.9}>
              <View style={styles.rowLeft}>
                <Text style={styles.monthLabel}>This Month</Text>
                <ChevronRight size={20} color={theme.textMuted} />
              </View>
            </TouchableOpacity>

            <View style={styles.statSplit}>
              <Text style={styles.bigDay}>{String(new Date().getDate()).padStart(2, '0')}</Text>
              <View style={styles.statDivider} />
              <View style={styles.statCol}>
                <Text style={styles.statSmall}>Expenses</Text>
                <Text style={styles.statVal}>-₹ {summary.totalExpense.toLocaleString()}</Text>
              </View>
              <View style={styles.statCol}>
                <Text style={styles.statSmall}>Income</Text>
                <Text style={styles.statVal}>₹ {summary.totalIncome.toLocaleString()}</Text>
              </View>
            </View>

            <View style={styles.budgetCard}>
              <View style={styles.budgetHeader}>
                <Text style={styles.budgetTitle}>Monthly budget</Text>
                <TouchableOpacity style={styles.settingPill} activeOpacity={0.85}>
                  <Settings size={16} color={theme.black} />
                  <Text style={styles.settingTxt}>Setting</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.budgetRow}>
                <View style={styles.ringWrap}>
                  <View style={styles.ringOuter}>
                    <Text style={styles.ringPct}>{pct}%</Text>
                    <Text style={styles.ringLbl}>Balance</Text>
                  </View>
                </View>
                <View style={styles.budgetList}>
                  <Text style={styles.budgetLine}>
                    Balance: <Text style={styles.budgetStrong}>₹ {balance.toLocaleString()}</Text>
                  </Text>
                  <Text style={styles.budgetLine}>
                    Budget: <Text style={styles.budgetStrong}>₹ {budget.toLocaleString()}</Text>
                  </Text>
                  <Text style={styles.budgetLine}>
                    Expenses: <Text style={styles.budgetStrong}>₹ {summary.totalExpense.toLocaleString()}</Text>
                  </Text>
                </View>
              </View>
              <Text style={styles.budgetHint}>
                Budget target is illustrative; connect your own limits when the API supports it.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.yellow },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scroll: { padding: 12, paddingBottom: 100 },
  card: { borderRadius: 20, overflow: 'hidden', backgroundColor: theme.white },
  yellowHead: { backgroundColor: theme.yellow, paddingVertical: 16, alignItems: 'center' },
  headTitle: { fontSize: 18, fontWeight: '800', color: theme.black },
  whiteBody: { padding: 16 },
  rowCard: { marginBottom: 12 },
  rowLeft: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  monthLabel: { fontSize: 16, fontWeight: '800', color: theme.text },
  statSplit: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.offWhite,
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  bigDay: { fontSize: 36, fontWeight: '900', color: theme.black, marginRight: 12 },
  statDivider: { width: 1, height: 48, backgroundColor: theme.border, marginRight: 14 },
  statCol: { flex: 1 },
  statSmall: { fontSize: 12, color: theme.textMuted, fontWeight: '700', marginBottom: 4 },
  statVal: { fontSize: 16, fontWeight: '800', color: theme.black },
  budgetCard: {
    backgroundColor: theme.offWhite,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: theme.border,
  },
  budgetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  budgetTitle: { fontSize: 16, fontWeight: '800', color: theme.text },
  settingPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: theme.yellow,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  settingTxt: { fontSize: 12, fontWeight: '800', color: theme.black },
  budgetRow: { flexDirection: 'row', alignItems: 'center' },
  ringWrap: { marginRight: 16 },
  ringOuter: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 10,
    borderColor: theme.yellow,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: theme.white,
  },
  ringPct: { fontSize: 16, fontWeight: '900', color: theme.black },
  ringLbl: { fontSize: 10, fontWeight: '700', color: theme.textMuted },
  budgetList: { flex: 1 },
  budgetLine: { fontSize: 14, color: theme.textMuted, marginBottom: 8, fontWeight: '600' },
  budgetStrong: { color: theme.black, fontWeight: '800' },
  budgetHint: { marginTop: 12, fontSize: 11, color: theme.textMuted, fontWeight: '600' },
});
