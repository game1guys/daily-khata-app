import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { Crown, Sparkles } from 'lucide-react-native';
import type { RootStackParamList } from '../../App';
import { WEB_PRICING_URL } from '../config/api';
import { theme } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'UpgradePlan'>;

const PLANS = [
  {
    key: 'free',
    name: 'Free',
    price: '₹0',
    period: 'Forever',
    blurb: 'Basic ledger, categories, and reports.',
    cta: 'Current on Me',
    planParam: 'free',
    primary: false,
  },
  {
    key: 'premium_mon',
    name: 'Premium Monthly',
    price: '₹99',
    period: '/ month',
    blurb: 'Full analytics, exports, and priority layout.',
    cta: 'Pay on website',
    planParam: 'premium_mon',
    primary: true,
  },
  {
    key: 'premium_yr',
    name: 'Premium Yearly',
    price: '₹799',
    period: '/ year',
    blurb: 'Best value — two months free vs monthly.',
    cta: 'Pay on website',
    planParam: 'premium_yr',
    primary: false,
  },
  {
    key: 'premium_life',
    name: 'Premium Lifetime',
    price: '₹1,999',
    period: 'one-time',
    blurb: 'Pay once, use premium features forever.',
    cta: 'Pay on website',
    planParam: 'premium_life',
    primary: false,
  },
] as const;

function openPricing(plan: string) {
  const url = `${WEB_PRICING_URL}?plan=${encodeURIComponent(plan)}`;
  Linking.openURL(url).catch(() => {
    Alert.alert('Could not open browser', 'Check your device connection or pricing URL in config.');
  });
}

export default function UpgradePlanScreen({ navigation }: Props) {
  return (
    <SafeAreaView style={styles.root} edges={['bottom']}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <Crown size={40} color={theme.black} />
          <Text style={styles.heroTitle}>Plans & payment</Text>
          <Text style={styles.heroSub}>
            Choose a plan on our secure website. After payment, your account updates automatically when you reopen the app.
          </Text>
        </View>

        {PLANS.map((p) => (
          <View key={p.key} style={[styles.planCard, p.primary && styles.planCardHighlight]}>
            <View style={styles.planHeader}>
              <Text style={styles.planName}>{p.name}</Text>
              {p.primary ? (
                <View style={styles.badge}>
                  <Sparkles size={14} color={theme.black} />
                  <Text style={styles.badgeTxt}>Popular</Text>
                </View>
              ) : null}
            </View>
            <Text style={styles.price}>
              {p.price}
              <Text style={styles.period}> {p.period}</Text>
            </Text>
            <Text style={styles.blurb}>{p.blurb}</Text>
            {p.key === 'free' ? (
              <Text style={styles.hintMuted}>You can keep using the free tier anytime.</Text>
            ) : (
              <TouchableOpacity
                style={[styles.cta, p.primary && styles.ctaStrong]}
                activeOpacity={0.9}
                onPress={() => {
                  Alert.alert(
                    'Continue to payment',
                    'You will switch to the browser to complete checkout (UPI, card, etc.).',
                    [
                      { text: 'Cancel', style: 'cancel' },
                      { text: 'Continue', onPress: () => openPricing(p.planParam) },
                    ]
                  );
                }}
              >
                <Text style={styles.ctaTxt}>{p.cta}</Text>
              </TouchableOpacity>
            )}
          </View>
        ))}

        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()} activeOpacity={0.9}>
          <Text style={styles.backTxt}>Back to Me</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.yellow },
  scroll: { padding: 16, paddingBottom: 32 },
  hero: {
    backgroundColor: theme.white,
    borderRadius: 20,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.border,
  },
  heroTitle: { fontSize: 22, fontWeight: '900', color: theme.text, marginTop: 8 },
  heroSub: { fontSize: 14, color: theme.textMuted, textAlign: 'center', marginTop: 8, lineHeight: 20, fontWeight: '600' },
  planCard: {
    backgroundColor: theme.white,
    borderRadius: 18,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: theme.border,
  },
  planCardHighlight: { borderColor: theme.black, borderWidth: 2 },
  planHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  planName: { fontSize: 17, fontWeight: '800', color: theme.text },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.yellow,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  badgeTxt: { fontSize: 11, fontWeight: '800', color: theme.black },
  price: { fontSize: 28, fontWeight: '900', color: theme.text, marginTop: 10 },
  period: { fontSize: 15, fontWeight: '700', color: theme.textMuted },
  blurb: { fontSize: 14, color: theme.textMuted, marginTop: 6, fontWeight: '600', lineHeight: 20 },
  hintMuted: { fontSize: 13, color: theme.textMuted, marginTop: 12, fontStyle: 'italic' },
  cta: {
    marginTop: 14,
    backgroundColor: theme.grayBg,
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  ctaStrong: { backgroundColor: theme.yellow },
  ctaTxt: { fontSize: 16, fontWeight: '800', color: theme.black },
  backBtn: { marginTop: 8, paddingVertical: 14, alignItems: 'center' },
  backTxt: { fontSize: 16, fontWeight: '800', color: theme.black, textDecorationLine: 'underline' },
});
