import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Modal,
  ActivityIndicator,
  Keyboard,
  Alert,
  Pressable,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { Delete, Calendar, ChevronDown, UserPlus } from 'lucide-react-native';
import { RootStackParamList } from '../../App';
import { API_URL } from '../config/api';
import { theme } from '../theme/colors';
import { CategoryGlyph } from '../utils/categoryIcon';

type Props = NativeStackScreenProps<RootStackParamList, 'AddTransaction'>;

type UdharDirection = 'given' | 'taken' | null;

function softCircleBg(hex?: string) {
  if (!hex || !/^#[0-9A-Fa-f]{6}$/.test(hex)) return theme.grayBg;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},0.28)`;
}

function evalFormula(raw: string): number | null {
  const s = raw.replace(/\s/g, '');
  const m = s.match(/^(\d+(?:\.\d*)?)([+-])(\d+(?:\.\d*)?)$/);
  if (!m) {
    const n = parseFloat(s);
    return Number.isFinite(n) ? n : null;
  }
  const a = parseFloat(m[1]);
  const b = parseFloat(m[3]);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
  return m[2] === '+' ? a + b : a - b;
}

function isUdharCategoryName(name: string) {
  return /udhar|उधार|loan|borrow|credit|debt/i.test(name);
}

export default function AddTransactionScreen({ navigation, route }: Props) {
  const initialType = route.params?.type ?? 'expense';
  const isEditMode = !!route.params?.transactionId;
  const [txType, setTxType] = useState<'expense' | 'income'>(initialType);

  const [categories, setCategories] = useState<any[]>([]);
  const [loadingCats, setLoadingCats] = useState(true);
  const [categoryId, setCategoryId] = useState<string | null>(null);

  const [parties, setParties] = useState<any[]>([]);
  const [partyId, setPartyId] = useState<string | null>(null);
  const [partyDisplayName, setPartyDisplayName] = useState('');
  const [partyModalOpen, setPartyModalOpen] = useState(false);
  const [partySearch, setPartySearch] = useState('');
  const [newPartyName, setNewPartyName] = useState('');

  const [udharType, setUdharType] = useState<UdharDirection>(null);

  const [formula, setFormula] = useState('0');
  const [memo, setMemo] = useState('');
  const [saving, setSaving] = useState(false);

  const [customOpen, setCustomOpen] = useState(false);
  const [customName, setCustomName] = useState('');
  const [categoryModalOpen, setCategoryModalOpen] = useState(false);

  const selectedCategory = useMemo(
    () => categories.find((c) => c.id === categoryId),
    [categories, categoryId]
  );

  const showUdharSection = useMemo(() => {
    if (!selectedCategory) return !!partyId || !!partyDisplayName;
    return isUdharCategoryName(selectedCategory.name) || !!partyId || !!partyDisplayName;
  }, [selectedCategory, partyId, partyDisplayName]);

  const fetchParties = useCallback(async () => {
    try {
      const token = await AsyncStorage.getItem('khata_session');
      const res = await axios.get(`${API_URL}/parties`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setParties(res.data?.parties || []);
    } catch (e) {
      console.log('parties error', e);
    }
  }, []);

  const fetchCats = useCallback(async () => {
    setLoadingCats(true);
    try {
      const token = await AsyncStorage.getItem('khata_session');
      const res = await axios.get(`${API_URL}/categories`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const list = (res.data?.categories || []).filter((c: any) => c.type === txType);
      setCategories(list);
      setCategoryId(null);
    } catch (e) {
      console.log('categories error', e);
    } finally {
      setLoadingCats(false);
    }
  }, [txType]);

  useEffect(() => {
    fetchCats();
  }, [fetchCats]);

  useEffect(() => {
    fetchParties();
  }, [fetchParties]);

  useEffect(() => {
    setUdharType(null);
  }, [categoryId]);

  const filteredParties = useMemo(() => {
    const q = partySearch.trim().toLowerCase();
    if (!q) return parties;
    return parties.filter((p) => p.name?.toLowerCase().includes(q));
  }, [parties, partySearch]);

  const appendDigit = (d: string) => {
    setFormula((prev) => {
      if (prev === '0' && d !== '.') return d;
      if (d === '.' && prev.includes('.')) return prev;
      return prev + d;
    });
  };

  const backspace = () => {
    setFormula((prev) => {
      if (prev.length <= 1) return '0';
      return prev.slice(0, -1);
    });
  };

  const appendOp = (op: '+' | '-') => {
    setFormula((prev) => {
      if (/[+-]$/.test(prev)) return prev.slice(0, -1) + op;
      return `${prev}${op}`;
    });
  };

  const onEquals = () => {
    const v = evalFormula(formula);
    if (v != null) setFormula(String(Math.round(v * 100) / 100));
  };

  const resolvedAmount = (): number | null => {
    let s = formula.replace(/\s/g, '');
    s = s.replace(/[+-]$/, '');
    const v = evalFormula(s);
    if (v == null || !Number.isFinite(v)) return null;
    return Math.round(v * 100) / 100;
  };

  const submitCustom = async () => {
    const name = customName.trim();
    if (!name) return;
    try {
      const token = await AsyncStorage.getItem('khata_session');
      const res = await axios.post(
        `${API_URL}/categories/custom`,
        { name, type: txType, icon: 'Tags', color: '#FFD740' },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const cat = res.data?.category;
      if (cat?.id) {
        await fetchCats();
        setCategoryId(cat.id);
      }
      setCustomOpen(false);
      setCustomName('');
      setCategoryModalOpen(false);
    } catch (e) {
      console.log('custom category error', e);
    }
  };

  const selectParty = (p: { id: string; name: string }) => {
    setPartyId(p.id);
    setPartyDisplayName(p.name);
    setPartyModalOpen(false);
    setPartySearch('');
    setNewPartyName('');
  };

  const createPartyQuick = async () => {
    const name = (newPartyName.trim() || partySearch.trim());
    if (!name) return;
    try {
      const token = await AsyncStorage.getItem('khata_session');
      const res = await axios.post(
        `${API_URL}/parties`,
        { name },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      const p = res.data?.party;
      if (p?.id) {
        await fetchParties();
        selectParty({ id: p.id, name: p.name });
      }
    } catch (e) {
      console.log('create party error', e);
    }
  };

  const clearParty = () => {
    setPartyId(null);
    setPartyDisplayName('');
    setUdharType(null);
  };

  const handleSave = async () => {
    Keyboard.dismiss();
    const amt = resolvedAmount();
    if (!amt || amt <= 0 || !categoryId) return;

    const hasParty = !!(partyId || partyDisplayName.trim());
    if (udharType && !hasParty) {
      Alert.alert('Party required', 'Choose or create a party before recording Udhar.');
      return;
    }

    try {
      setSaving(true);
      const token = await AsyncStorage.getItem('khata_session');
      const headers = { Authorization: `Bearer ${token}` };

      const payload: Record<string, unknown> = {
        amount: amt,
        type: txType,
        category_id: categoryId,
        note: memo.trim() || undefined,
      };

      if (partyId) {
        payload.party_id = partyId;
      } else if (partyDisplayName.trim()) {
        payload.party_name = partyDisplayName.trim();
      }

      const res = await axios.post(`${API_URL}/transactions`, payload, { headers });
      const tx = res.data?.transaction;
      const resolvedPartyId = tx?.party_id ?? partyId;

      if (udharType && resolvedPartyId) {
        await axios.post(
          `${API_URL}/parties/udhar-transaction`,
          {
            party_id: resolvedPartyId,
            amount: amt,
            type: udharType,
            note: memo.trim() || undefined,
          },
          { headers }
        );
      }

      navigation.goBack();
    } catch (e: any) {
      Alert.alert('Could not save', e.response?.data?.error || e.message || 'Try again.');
    } finally {
      setSaving(false);
    }
  };

  const selectCategoryFromModal = (id: string) => {
    setCategoryId(id);
    setCategoryModalOpen(false);
  };

  const amt = resolvedAmount();
  const canSave = !!amt && amt > 0 && !!categoryId;

  const screenTitle = isEditMode ? 'Edit' : 'New record';

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <View style={styles.sheet}>
        <View style={styles.yellowBar}>
          <TouchableOpacity onPress={() => navigation.goBack()} hitSlop={12}>
            <Text style={styles.cancelTxt}>Cancel</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{screenTitle}</Text>
          <TouchableOpacity
            onPress={handleSave}
            disabled={!canSave || saving}
            hitSlop={12}
            style={styles.saveHeaderBtn}
            activeOpacity={0.85}
          >
            {saving ? (
              <ActivityIndicator size="small" color={theme.black} />
            ) : (
              <Text style={[styles.saveHeaderTxt, !canSave && styles.saveHeaderTxtDisabled]}>Save</Text>
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.segment}>
          <TouchableOpacity
            style={[styles.segBtn, txType === 'expense' && styles.segBtnOn]}
            onPress={() => setTxType('expense')}
            activeOpacity={0.9}
          >
            <Text style={[styles.segTxt, txType === 'expense' && styles.segTxtOn]}>Expenses</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.segBtn, txType === 'income' && styles.segBtnOn]}
            onPress={() => setTxType('income')}
            activeOpacity={0.9}
          >
            <Text style={[styles.segTxt, txType === 'income' && styles.segTxtOn]}>Income</Text>
          </TouchableOpacity>
        </View>

        {loadingCats ? (
          <View style={styles.loader}>
            <ActivityIndicator color={theme.black} />
          </View>
        ) : (
          <View style={styles.categoryBlock}>
            <Text style={styles.pickLabel}>Category</Text>
            <TouchableOpacity
              style={styles.categoryChooseBtn}
              onPress={() => setCategoryModalOpen(true)}
              activeOpacity={0.88}
            >
              <View style={styles.categoryChooseLeft}>
                {selectedCategory ? (
                  <View style={[styles.catSmallCircle, { backgroundColor: softCircleBg(selectedCategory.color) }]}>
                    <CategoryGlyph
                      iconKey={selectedCategory.icon}
                      color={
                        selectedCategory.color && /^#[0-9A-Fa-f]{6}$/.test(selectedCategory.color)
                          ? selectedCategory.color
                          : theme.text
                      }
                      size={20}
                    />
                  </View>
                ) : (
                  <View style={[styles.catSmallCircle, { backgroundColor: theme.grayBg }]} />
                )}
                <Text
                  style={[styles.categoryChooseTxt, !selectedCategory && styles.categoryChoosePlaceholder]}
                  numberOfLines={1}
                >
                  {selectedCategory ? selectedCategory.name : 'Choose category'}
                </Text>
              </View>
              <ChevronDown size={22} color={theme.textMuted} />
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.metaSection}>
          <Text style={styles.metaLabel}>Party (optional)</Text>
          <TouchableOpacity
            style={styles.partyRow}
            onPress={() => setPartyModalOpen(true)}
            activeOpacity={0.9}
          >
            <View style={styles.partyIconSlot}>
              <UserPlus size={20} color={theme.text} />
            </View>
            <Text style={[styles.partyRowText, !partyDisplayName && styles.partyPlaceholder]} numberOfLines={1}>
              {partyDisplayName || 'Tap to choose or add party'}
            </Text>
            <ChevronDown size={20} color={theme.textMuted} />
          </TouchableOpacity>
          {partyDisplayName ? (
            <TouchableOpacity onPress={clearParty} hitSlop={8}>
              <Text style={styles.clearParty}>Clear party</Text>
            </TouchableOpacity>
          ) : null}

          {showUdharSection ? (
            <View style={styles.udharBlock}>
              <Text style={styles.metaLabel}>Udhar khata (optional)</Text>
              <Text style={styles.udharHint}>
                Given = I lent · Taken = I borrowed. Saved to your party ledger after the main entry.
              </Text>
              <View style={styles.udharRow}>
                <TouchableOpacity
                  style={[styles.udharChip, styles.udharChipLeft, udharType === 'given' && styles.udharChipOn]}
                  onPress={() => setUdharType(udharType === 'given' ? null : 'given')}
                  activeOpacity={0.85}
                >
                  <Text style={[styles.udharChipTxt, udharType === 'given' && styles.udharChipTxtOn]}>Given</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.udharChip, udharType === 'taken' && styles.udharChipOn]}
                  onPress={() => setUdharType(udharType === 'taken' ? null : 'taken')}
                  activeOpacity={0.85}
                >
                  <Text style={[styles.udharChipTxt, udharType === 'taken' && styles.udharChipTxtOn]}>Taken</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
        </View>

        <View style={styles.keypadWrap}>
          <TextInput
            style={styles.memo}
            placeholder="Memo : Enter a memo..."
            placeholderTextColor={theme.textMuted}
            value={memo}
            onChangeText={setMemo}
          />
          <Text style={styles.formulaDisp} numberOfLines={1}>
            {formula}
          </Text>

          <View style={styles.keypad}>
            <View style={styles.keyCol}>
              {[
                ['7', '8', '9'],
                ['4', '5', '6'],
                ['1', '2', '3'],
                ['.', '0', 'del'],
              ].map((row, ri) => (
                <View key={ri} style={styles.keyRow}>
                  {row.map((k) => (
                    <TouchableOpacity
                      key={k}
                      style={styles.keyBtn}
                      onPress={() => (k === 'del' ? backspace() : appendDigit(k))}
                    >
                      {k === 'del' ? (
                        <Delete size={22} color={theme.text} />
                      ) : (
                        <Text style={styles.keyTxt}>{k}</Text>
                      )}
                    </TouchableOpacity>
                  ))}
                </View>
              ))}
            </View>
            <View style={styles.keySide}>
              <TouchableOpacity style={styles.sideBtn} onPress={() => {}}>
                <Calendar size={20} color={theme.text} />
                <Text style={styles.sideTxt}>Today</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sideBtn} onPress={() => appendOp('+')}>
                <Text style={styles.sideMath}>+</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.sideBtn} onPress={() => appendOp('-')}>
                <Text style={styles.sideMath}>-</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.sideBtn, styles.equalsBtn]} onPress={onEquals}>
                <Text style={styles.equalsTxt}>=</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity
            style={[styles.saveBig, (!canSave || saving) && styles.saveBigDisabled]}
            onPress={handleSave}
            disabled={!canSave || saving}
            activeOpacity={0.9}
          >
            {saving ? (
              <ActivityIndicator color={theme.black} />
            ) : (
              <Text style={styles.saveBigTxt}>Save entry</Text>
            )}
          </TouchableOpacity>
        </View>
      </View>

      <Modal visible={customOpen} transparent animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Custom category</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Name"
              value={customName}
              onChangeText={setCustomName}
              autoFocus
            />
            <View style={styles.modalRow}>
              <TouchableOpacity style={styles.modalBtnGhost} onPress={() => setCustomOpen(false)}>
                <Text style={styles.modalBtnGhostTxt}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, styles.modalBtnPad]} onPress={submitCustom}>
                <Text style={styles.modalBtnTxt}>Create</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal visible={categoryModalOpen} transparent animationType="fade">
        <View style={styles.catModalOverlay}>
          <Pressable style={styles.catModalBackdrop} onPress={() => setCategoryModalOpen(false)} />
          <View style={styles.catModalSheet}>
            <Text style={styles.catModalTitle}>Choose category</Text>
            <FlatList
              data={categories}
              keyExtractor={(item) => String(item.id)}
              style={styles.catModalList}
              keyboardShouldPersistTaps="handled"
              renderItem={({ item }) => {
                const sel = categoryId === item.id;
                const lineColor = item.color && /^#[0-9A-Fa-f]{6}$/.test(item.color) ? item.color : theme.text;
                return (
                  <TouchableOpacity
                    style={[styles.catModalRow, sel && styles.catModalRowOn]}
                    onPress={() => selectCategoryFromModal(item.id)}
                    activeOpacity={0.85}
                  >
                    <View style={[styles.catModalIcon, { backgroundColor: sel ? theme.yellow : softCircleBg(item.color) }]}>
                      <CategoryGlyph iconKey={item.icon} color={lineColor} size={22} />
                    </View>
                    <Text style={[styles.catModalRowTxt, sel && styles.catModalRowTxtOn]} numberOfLines={1}>
                      {item.name}
                    </Text>
                  </TouchableOpacity>
                );
              }}
              ListFooterComponent={
                <TouchableOpacity
                  style={styles.catModalCustom}
                  onPress={() => {
                    setCategoryModalOpen(false);
                    setCustomOpen(true);
                  }}
                  activeOpacity={0.85}
                >
                  <View style={[styles.catModalIcon, { backgroundColor: theme.grayBg }]}>
                    <Text style={styles.catModalPlus}>+</Text>
                  </View>
                  <Text style={styles.catModalRowTxt}>Custom category</Text>
                </TouchableOpacity>
              }
            />
            <TouchableOpacity style={styles.catModalClose} onPress={() => setCategoryModalOpen(false)}>
              <Text style={styles.catModalCloseTxt}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal visible={partyModalOpen} transparent animationType="slide">
        <View style={styles.modalBg}>
          <View style={styles.partyModalCard}>
            <Text style={styles.modalTitle}>Party</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Search or type new name"
              value={partySearch}
              onChangeText={setPartySearch}
            />
            <TextInput
              style={[styles.modalInput, styles.mtSm]}
              placeholder="New party name (if creating)"
              value={newPartyName}
              onChangeText={setNewPartyName}
            />
            <TouchableOpacity style={styles.createPartyBtn} onPress={createPartyQuick} activeOpacity={0.9}>
              <Text style={styles.createPartyBtnTxt}>Create party & select</Text>
            </TouchableOpacity>
            {partySearch.trim() ? (
              <TouchableOpacity
                style={styles.useNameBtn}
                onPress={() => {
                  setPartyId(null);
                  setPartyDisplayName(partySearch.trim());
                  setPartyModalOpen(false);
                  setPartySearch('');
                  setNewPartyName('');
                }}
                activeOpacity={0.9}
              >
                <Text style={styles.useNameBtnTxt}>
                  Use &quot;{partySearch.trim()}&quot; without saving to list
                </Text>
              </TouchableOpacity>
            ) : null}
            <FlatList
              data={filteredParties}
              keyExtractor={(item) => item.id}
              style={styles.partyList}
              keyboardShouldPersistTaps="handled"
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.partyListItem} onPress={() => selectParty(item)}>
                  <Text style={styles.partyListItemTxt}>{item.name}</Text>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <Text style={styles.partyEmpty}>No saved names yet. Create one above.</Text>
              }
            />
            <TouchableOpacity style={styles.modalBtnGhost} onPress={() => setPartyModalOpen(false)}>
              <Text style={[styles.modalBtnGhostTxt, { textAlign: 'center', marginTop: 8 }]}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.yellow },
  sheet: { flex: 1, backgroundColor: theme.white, borderTopLeftRadius: 22, borderTopRightRadius: 22, overflow: 'hidden' },
  yellowBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: theme.yellow,
    paddingHorizontal: 12,
    paddingVertical: 14,
  },
  cancelTxt: { fontSize: 16, fontWeight: '700', color: theme.text, minWidth: 56 },
  headerTitle: { fontSize: 18, fontWeight: '900', color: theme.black, flex: 1, textAlign: 'center' },
  saveHeaderBtn: { minWidth: 56, alignItems: 'flex-end', justifyContent: 'center' },
  saveHeaderTxt: { fontSize: 16, fontWeight: '900', color: theme.black },
  saveHeaderTxtDisabled: { color: theme.textMuted, fontWeight: '700' },
  segment: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginVertical: 10,
    backgroundColor: theme.offWhite,
    borderRadius: 12,
    padding: 4,
  },
  segBtn: { flex: 1, paddingVertical: 10, borderRadius: 10, alignItems: 'center' },
  segBtnOn: { backgroundColor: theme.black },
  segTxt: { fontWeight: '800', color: theme.text },
  segTxtOn: { color: theme.white },
  loader: { padding: 24, alignItems: 'center' },
  categoryBlock: { paddingHorizontal: 16, paddingBottom: 8 },
  pickLabel: { fontWeight: '800', color: theme.textMuted, marginBottom: 8, marginLeft: 2, fontSize: 12, letterSpacing: 0.5, textTransform: 'uppercase' },
  categoryChooseBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: theme.offWhite,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: theme.border,
  },
  categoryChooseLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, marginRight: 10 },
  catSmallCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  categoryChooseTxt: { flex: 1, fontSize: 16, fontWeight: '800', color: theme.text },
  categoryChoosePlaceholder: { color: theme.textMuted, fontWeight: '700' },
  catModalOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  catModalBackdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  catModalSheet: {
    backgroundColor: theme.white,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 28,
    maxHeight: '72%',
  },
  catModalTitle: { fontSize: 18, fontWeight: '900', color: theme.black, marginBottom: 12, textAlign: 'center' },
  catModalList: { maxHeight: 360 },
  catModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: theme.border,
  },
  catModalRowOn: { backgroundColor: 'rgba(255, 215, 64, 0.2)', marginHorizontal: -8, paddingHorizontal: 8, borderRadius: 12, borderBottomWidth: 0 },
  catModalIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  catModalPlus: { fontSize: 24, fontWeight: '900', color: theme.text },
  catModalRowTxt: { flex: 1, fontSize: 16, fontWeight: '700', color: theme.text },
  catModalRowTxtOn: { fontWeight: '900' },
  catModalCustom: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, marginTop: 4 },
  catModalClose: { marginTop: 12, alignItems: 'center', paddingVertical: 12 },
  catModalCloseTxt: { fontSize: 16, fontWeight: '800', color: theme.textMuted },
  metaSection: {
    paddingHorizontal: 16,
    paddingBottom: 10,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: theme.border,
    paddingTop: 12,
  },
  metaLabel: { fontSize: 12, fontWeight: '800', color: theme.textMuted, marginBottom: 8, textTransform: 'uppercase', letterSpacing: 0.6 },
  partyIconSlot: { marginRight: 10 },
  partyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.offWhite,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  partyRowText: { flex: 1, fontSize: 16, fontWeight: '700', color: theme.text, marginRight: 8 },
  partyPlaceholder: { color: theme.textMuted, fontWeight: '600' },
  clearParty: { marginTop: 8, fontSize: 13, fontWeight: '700', color: '#c62828' },
  udharBlock: { marginTop: 14 },
  udharHint: { fontSize: 12, color: theme.textMuted, marginBottom: 10, lineHeight: 18 },
  udharRow: { flexDirection: 'row' },
  udharChip: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: theme.offWhite,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: theme.border,
  },
  udharChipLeft: { marginRight: 10 },
  udharChipOn: { backgroundColor: theme.black, borderColor: theme.black },
  udharChipTxt: { fontSize: 14, fontWeight: '800', color: theme.text },
  udharChipTxtOn: { color: theme.white },
  keypadWrap: {
    backgroundColor: theme.grayBg,
    paddingHorizontal: 12,
    paddingTop: 12,
    paddingBottom: 16,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  memo: {
    backgroundColor: theme.white,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: theme.text,
    marginBottom: 8,
  },
  formulaDisp: { textAlign: 'right', fontSize: 22, fontWeight: '800', color: theme.text, marginBottom: 10 },
  keypad: { flexDirection: 'row' },
  keyCol: { flex: 1, marginRight: 8 },
  keyRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  keyBtn: {
    flex: 1,
    marginHorizontal: 3,
    backgroundColor: theme.white,
    borderRadius: 12,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  keyTxt: { fontSize: 20, fontWeight: '800', color: theme.text },
  keySide: { width: 76, justifyContent: 'space-between' },
  sideBtn: {
    backgroundColor: theme.white,
    borderRadius: 12,
    flex: 1,
    marginBottom: 8,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 44,
  },
  sideTxt: { fontSize: 10, fontWeight: '700', color: theme.text, marginTop: 2 },
  sideMath: { fontSize: 22, fontWeight: '900', color: theme.text },
  equalsBtn: { backgroundColor: theme.yellow, flex: 1.2, marginBottom: 0 },
  equalsTxt: { fontSize: 26, fontWeight: '900', color: theme.black },
  saveBig: {
    marginTop: 12,
    backgroundColor: theme.yellow,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveBigDisabled: { opacity: 0.45 },
  saveBigTxt: { fontSize: 17, fontWeight: '900', color: theme.black },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.35)',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: { backgroundColor: theme.white, borderRadius: 16, padding: 20 },
  partyModalCard: { backgroundColor: theme.white, borderRadius: 16, padding: 20, maxHeight: '85%' },
  modalTitle: { fontSize: 18, fontWeight: '900', marginBottom: 12, color: theme.text },
  modalInput: {
    borderWidth: 1,
    borderColor: theme.border,
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    marginBottom: 8,
  },
  mtSm: { marginTop: 0 },
  modalRow: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 8 },
  modalBtnGhost: { paddingVertical: 12, paddingHorizontal: 16 },
  modalBtnGhostTxt: { fontWeight: '800', color: theme.textMuted },
  modalBtn: { backgroundColor: theme.yellow, paddingVertical: 12, paddingHorizontal: 22, borderRadius: 12 },
  modalBtnPad: { marginLeft: 12 },
  modalBtnTxt: { fontWeight: '900', color: theme.black },
  createPartyBtn: {
    backgroundColor: theme.black,
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 10,
  },
  createPartyBtnTxt: { color: theme.white, fontWeight: '900', fontSize: 15 },
  useNameBtn: {
    paddingVertical: 12,
    paddingHorizontal: 8,
    marginBottom: 12,
    alignItems: 'center',
  },
  useNameBtnTxt: { fontSize: 13, fontWeight: '800', color: theme.text, textAlign: 'center' },
  partyList: { maxHeight: 220 },
  partyListItem: {
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: theme.border,
  },
  partyListItemTxt: { fontSize: 16, fontWeight: '700', color: theme.text },
  partyEmpty: { textAlign: 'center', color: theme.textMuted, paddingVertical: 16, fontWeight: '600' },
});
