import React, { useState, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import { useFocusEffect } from '@react-navigation/native';
import { ChevronDown } from 'lucide-react-native';
import type { MainTabParamList, RootStackParamList } from '../../App';
import { API_URL } from '../config/api';
import { theme } from '../theme/colors';
import { CategoryIconCircle } from '../utils/categoryIcon';

type Props = CompositeScreenProps<
  BottomTabScreenProps<MainTabParamList, 'Records'>,
  NativeStackScreenProps<RootStackParamList>
>;

export default function RecordsScreen(_props: Props) {
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [summary, setSummary] = useState({
    totalIncome: 0,
    totalExpense: 0,
    totalSavings: 0,
    categorySplit: [] as { name: string; color: string; total: number }[],
  });
  const [transactions, setTransactions] = useState<any[]>([]);
  const [listFilter, setListFilter] = useState<'month' | 'all'>('month');

  const fetchData = async () => {
    try {
      const token = await AsyncStorage.getItem('khata_session');
      if (!token) throw new Error('Unauthenticated');
      const config = { headers: { Authorization: `Bearer ${token}` } };
      const [sumRes, txRes] = await Promise.all([
        axios.get(`${API_URL}/transactions/summary`, config),
        axios.get(`${API_URL}/transactions?limit=80`, config),
      ]);
      if (sumRes.data?.summary) setSummary(sumRes.data.summary);
      if (txRes.data?.transactions) setTransactions(txRes.data.transactions);
    } catch (e) {
      console.log('Records fetch error', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      fetchData();
    }, [])
  );

  const now = new Date();
  const yNow = now.getFullYear();
  const mNow = now.getMonth();
  const dateLabel = `${yNow} ${String(mNow + 1).padStart(2, '0')}`;

  const visibleTransactions = useMemo(() => {
    if (listFilter === 'all') return transactions;
    return transactions.filter((tx) => {
      const d = new Date(tx.transaction_date);
      return d.getMonth() === mNow && d.getFullYear() === yNow;
    });
  }, [transactions, listFilter, yNow, mNow]);

  if (loading && !refreshing) {
    return (
      <View style={[styles.root, styles.center]}>
        <ActivityIndicator size="large" color={theme.black} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor={theme.black} />
        }
        contentContainerStyle={styles.scroll}
      >
        <View style={styles.sheet}>
          <View style={styles.sheetYellow}>
            <Text style={styles.mmTitle}>Money Manager</Text>
            <View style={styles.dateRow}>
              <View style={styles.datePill}>
                <Text style={styles.datePillText}>{dateLabel}</Text>
                <ChevronDown size={18} color={theme.black} />
              </View>
              <View style={styles.filterRow}>
                <TouchableOpacity
                  style={[styles.filterChip, listFilter === 'month' && styles.filterChipOn]}
                  onPress={() => setListFilter('month')}
                >
                  <Text style={[styles.filterChipTxt, listFilter === 'month' && styles.filterChipTxtOn]}>This month</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.filterChip, listFilter === 'all' && styles.filterChipOn]}
                  onPress={() => setListFilter('all')}
                >
                  <Text style={[styles.filterChipTxt, listFilter === 'all' && styles.filterChipTxtOn]}>All</Text>
                </TouchableOpacity>
              </View>
            </View>
            <View style={styles.summaryRow}>
              <View style={styles.summaryCol}>
                <Text style={styles.summaryLabel}>Expenses</Text>
                <Text style={styles.summaryExpense}>-₹ {summary.totalExpense.toLocaleString()}</Text>
              </View>
              <View style={styles.summaryCol}>
                <Text style={styles.summaryLabel}>Income</Text>
                <Text style={styles.summaryIncome}>₹ {summary.totalIncome.toLocaleString()}</Text>
              </View>
            </View>
          </View>

          <View style={styles.sheetWhite}>
            {visibleTransactions.length === 0 ? (
              <Text style={styles.empty}>No records in this view. Tap + to add.</Text>
            ) : (
              visibleTransactions.map((tx: any, i: number) => {
                const isInc = tx.type === 'income';
                const cat = tx.categories;
                const bg = cat?.color ? `${cat.color}33` : theme.grayBg;
                return (
                  <View key={tx.id || i} style={styles.txRow}>
                    <CategoryIconCircle iconKey={cat?.icon} color={theme.text} bg={bg} size={20} />
                    <View style={styles.txMid}>
                      <Text style={styles.txCat} numberOfLines={1}>
                        {cat?.name || 'Uncategorized'}
                      </Text>
                      {tx.note ? (
                        <Text style={styles.txNote} numberOfLines={1}>
                          {tx.note}
                        </Text>
                      ) : null}
                    </View>
                    <Text style={[styles.txAmt, isInc ? styles.txAmtIn : styles.txAmtOut]}>
                      {isInc ? '' : '-'}₹ {Number(tx.amount).toLocaleString()}
                    </Text>
                  </View>
                );
              })
            )}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: theme.yellow,
  },
  center: { justifyContent: 'center', alignItems: 'center' },
  scroll: { paddingBottom: 100 },
  sheet: {
    marginHorizontal: 12,
    marginTop: 8,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: theme.white,
  },
  sheetYellow: {
    backgroundColor: theme.yellow,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 20,
  },
  mmTitle: {
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '800',
    color: theme.black,
    marginBottom: 12,
  },
  dateRow: { alignItems: 'flex-start', marginBottom: 16, width: '100%' },
  filterRow: { flexDirection: 'row', marginTop: 12 },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.5)',
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(0,0,0,0.08)',
  },
  filterChipOn: { backgroundColor: theme.black, borderColor: theme.black },
  filterChipTxt: { fontSize: 13, fontWeight: '800', color: theme.text },
  filterChipTxtOn: { color: theme.white },
  datePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.5)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
  },
  datePillText: { fontSize: 16, fontWeight: '800', color: theme.black },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between' },
  summaryCol: { flex: 1 },
  summaryLabel: { fontSize: 13, fontWeight: '700', color: theme.textMuted, marginBottom: 6 },
  summaryExpense: { fontSize: 22, fontWeight: '900', color: theme.black },
  summaryIncome: { fontSize: 22, fontWeight: '900', color: theme.black },
  sheetWhite: {
    backgroundColor: theme.white,
    paddingHorizontal: 16,
    paddingTop: 8,
    paddingBottom: 24,
    minHeight: 120,
  },
  empty: {
    textAlign: 'center',
    color: theme.textMuted,
    paddingVertical: 32,
    fontWeight: '600',
  },
  txRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: theme.border,
  },
  txMid: { flex: 1, marginLeft: 12 },
  txCat: { fontSize: 16, fontWeight: '800', color: theme.text },
  txNote: { fontSize: 13, color: theme.textMuted, marginTop: 2 },
  txAmt: { fontSize: 16, fontWeight: '900' },
  txAmtIn: { color: '#2e7d32' },
  txAmtOut: { color: theme.black },
});
