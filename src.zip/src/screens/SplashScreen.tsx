import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet, Easing, Text, ActivityIndicator } from 'react-native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../App';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Splash'>;
};

export default function SplashScreen({ navigation }: Props) {
  const scaleValue = useRef(new Animated.Value(0.6)).current;
  const opacityValue = useRef(new Animated.Value(0)).current;
  const slideUpValue = useRef(new Animated.Value(20)).current;

  // Ambient breathing background aura
  const auraPulse = useRef(new Animated.Value(0.3)).current;

  useEffect(() => {
    // 1. Trigger Immersive Fade In & Scale UP for the Logo
    Animated.parallel([
      Animated.timing(scaleValue, {
        toValue: 1,
        duration: 900,
        easing: Easing.out(Easing.exp),
        useNativeDriver: true,
      }),
      Animated.timing(opacityValue, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideUpValue, {
        toValue: 0,
        duration: 900,
        easing: Easing.out(Easing.back(1.5)),
        useNativeDriver: true,
      })
    ]).start();

    // 2. Continuous breathing aura animation matching the rainbow vibe of the logo
    Animated.loop(
      Animated.sequence([
        Animated.timing(auraPulse, {
          toValue: 0.6,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(auraPulse, {
          toValue: 0.3,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        })
      ])
    ).start();

    // 3. Await minimal branding time before Auth Redirect
    const timer = setTimeout(async () => {
      try {
        const token = await AsyncStorage.getItem('khata_session');
        if (token) {
          navigation.replace('Main');
        } else {
          navigation.replace('Login');
        }
      } catch (err) {
        navigation.replace('Login');
      }
    }, 2800);

    return () => clearTimeout(timer);
  }, [navigation, scaleValue, opacityValue, slideUpValue, auraPulse]);

  return (
    <View style={styles.container}>

      {/* Ambient Animated Aura underneath the Logo (Rainbow/Gold vibe) */}
      <Animated.View style={[styles.auraWrapper, { opacity: auraPulse, transform: [{ scale: scaleValue }] }]}>
        <LinearGradient
          colors={['#fbd38d', '#f6e05e', '#68d391', '#63b3ed']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.auraBlob}
        />
      </Animated.View>

      <Animated.Image
        source={require('../../assets/app_icon.jpg')}
        style={[
          styles.logo,
          {
            opacity: opacityValue,
            transform: [{ scale: scaleValue }, { translateY: slideUpValue }],
          }
        ]}
        resizeMode="contain"
      />

      <Animated.Text style={[
        styles.tagline,
        {
          opacity: opacityValue,
          transform: [{ translateY: slideUpValue }]
        }
      ]}>
        Your Premium Digital Ledger.
      </Animated.Text>

      <Animated.View style={[styles.bottomLoader, { opacity: opacityValue }]}>
        <ActivityIndicator size="small" color="#3b82f6" />
        <Text style={styles.loaderText}>Syncing securely...</Text>
      </Animated.View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#030712',
    alignItems: 'center',
    justifyContent: 'center',
  },
  auraWrapper: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 350,
    height: 350,
    zIndex: 0,
  },
  auraBlob: {
    width: '100%',
    height: '100%',
    borderRadius: 175,
    opacity: 0.12,
    shadowColor: '#38bdf8',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 80,
    elevation: 25,
    transform: [{ scale: 1.1 }]
  },
  logo: {
    width: 220,
    height: 220,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
    zIndex: 10,
  },
  tagline: {
    color: '#cbd5e1',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 4,
    marginTop: 45,
    textTransform: 'uppercase',
    textShadowColor: 'rgba(56, 189, 248, 0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
  },
  bottomLoader: {
    position: 'absolute',
    bottom: 60,
    alignItems: 'center'
  },
  loaderText: {
    marginTop: 12,
    fontSize: 13,
    fontWeight: '700',
    color: '#94a3b8',
    letterSpacing: 1.2,
    textTransform: 'uppercase'
  }
});
