import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CommonActions, useFocusEffect } from '@react-navigation/native';
import type { CompositeScreenProps } from '@react-navigation/native';
import type { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import type { NativeStackNavigationProp, NativeStackScreenProps } from '@react-navigation/native-stack';
import axios from 'axios';
import { LogOut, User, Mail, Phone, Crown, ChevronRight } from 'lucide-react-native';
import type { MainTabParamList, RootStackParamList } from '../../App';
import { theme } from '../theme/colors';
import { API_URL } from '../config/api';
import type { MePayload } from '../utils/profileCache';
import { loadCachedMe, persistMePayload } from '../utils/profileCache';

type Props = CompositeScreenProps<
  BottomTabScreenProps<MainTabParamList, 'Me'>,
  NativeStackScreenProps<RootStackParamList>
>;

const TIER_LABELS: Record<string, string> = {
  free: 'Free',
  premium_mon: 'Premium (Monthly)',
  premium_yr: 'Premium (Yearly)',
  premium_life: 'Premium (Lifetime)',
};

function tierLabel(tier: string) {
  return TIER_LABELS[tier] ?? tier;
}

function formatEndDate(iso: string | null | undefined) {
  if (!iso) return '—';
  try {
    const d = new Date(iso);
    return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return iso;
  }
}

function initials(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return 'U';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export default function ProfileScreen({ navigation }: Props) {
  const [me, setMe] = useState<MePayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchMe = useCallback(async (isRefresh: boolean, hasCachedMe: boolean) => {
    try {
      if (isRefresh) setRefreshing(true);
      else if (!hasCachedMe) setLoading(true);
      const token = await AsyncStorage.getItem('khata_session');
      if (!token) {
        setLoading(false);
        setRefreshing(false);
        return;
      }
      const { data } = await axios.get<MePayload>(`${API_URL}/profile/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setMe(data);
      await persistMePayload(data);
    } catch {
      const cached = await loadCachedMe();
      if (cached) setMe(cached);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      (async () => {
        const cached = await loadCachedMe();
        if (cancelled) return;
        if (cached) setMe(cached);
        await fetchMe(false, !!cached);
      })();
      return () => {
        cancelled = true;
      };
    }, [fetchMe])
  );

  const onLogout = () => {
    Alert.alert('Sign out', 'Leave Daily-KHATA?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign out',
        style: 'destructive',
        onPress: async () => {
          await AsyncStorage.multiRemove(['khata_session', 'khata_profile']);
          navigation.getParent()?.dispatch(CommonActions.reset({ index: 0, routes: [{ name: 'Login' }] }));
        },
      },
    ]);
  };

  const openUpgrade = () => {
    const parent = navigation.getParent() as NativeStackNavigationProp<RootStackParamList> | undefined;
    parent?.navigate('UpgradePlan');
  };

  const tier = me?.subscription?.tier ?? 'free';

  return (
    <SafeAreaView style={styles.root} edges={['top']}>
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => fetchMe(true, true)} tintColor={theme.black} />}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.card}>
          <View style={styles.yellow}>
            <Text style={styles.screenTitle}>Me</Text>
          </View>

          {loading && !me ? (
            <View style={styles.loadingBox}>
              <ActivityIndicator color={theme.black} />
            </View>
          ) : null}

          {me ? (
            <>
              <View style={styles.avatarRow}>
                <View style={styles.avatar}>
                  <Text style={styles.avatarTxt}>{initials(me.user.full_name)}</Text>
                </View>
                <View style={styles.avatarMeta}>
                  <Text style={styles.displayName}>{me.user.full_name}</Text>
                  <Text style={styles.memberSince}>
                    Member since {formatEndDate(me.member_since ?? undefined)}
                  </Text>
                </View>
              </View>

              <View style={styles.planBanner}>
                <View style={styles.planHeaderRow}>
                  <Crown size={22} color={theme.black} />
                  <Text style={styles.planTitle}>Your plan</Text>
                </View>
                <Text style={styles.planTier}>{tierLabel(tier)}</Text>
                <Text style={styles.planRenew}>
                  {tier === 'free'
                    ? 'Upgrade for full analytics and exports.'
                    : `Renews / valid until ${formatEndDate(me.subscription.end_date)}`}
                </Text>
                <TouchableOpacity style={styles.upgradeBannerBtn} onPress={openUpgrade} activeOpacity={0.9}>
                  <Text style={styles.upgradeBannerBtnTxt}>
                    {tier === 'free' ? 'Upgrade plan' : 'Change or renew plan'}
                  </Text>
                  <ChevronRight size={20} color={theme.black} />
                </TouchableOpacity>
              </View>

              <Text style={styles.sectionLabel}>Account</Text>
              <View style={styles.detailRow}>
                <Mail size={18} color={theme.textMuted} />
                <View style={styles.detailTextWrap}>
                  <Text style={styles.detailMuted}>Email</Text>
                  <Text style={styles.detailValue}>{me.user.email ?? '—'}</Text>
                </View>
              </View>
              <View style={styles.detailRow}>
                <Phone size={18} color={theme.textMuted} />
                <View style={styles.detailTextWrap}>
                  <Text style={styles.detailMuted}>Phone</Text>
                  <Text style={styles.detailValue}>{me.user.phone ?? '—'}</Text>
                </View>
              </View>
              <View style={styles.detailRow}>
                <User size={18} color={theme.textMuted} />
                <View style={styles.detailTextWrap}>
                  <Text style={styles.detailMuted}>User ID</Text>
                  <Text style={styles.detailValueMono} numberOfLines={1}>
                    {me.user.id}
                  </Text>
                </View>
              </View>

              <TouchableOpacity style={styles.upgradeOutline} onPress={openUpgrade} activeOpacity={0.9}>
                <Crown size={20} color={theme.black} />
                <Text style={styles.upgradeOutlineTxt}>Plans & payment</Text>
                <ChevronRight size={20} color={theme.textMuted} />
              </TouchableOpacity>

              <TouchableOpacity style={styles.outBtn} onPress={onLogout} activeOpacity={0.9}>
                <LogOut size={20} color={theme.black} />
                <Text style={styles.outTxt}>Sign out</Text>
              </TouchableOpacity>
            </>
          ) : !loading ? (
            <Text style={styles.fallback}>Could not load profile. Pull to refresh.</Text>
          ) : null}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: theme.yellow },
  scroll: { flex: 1 },
  scrollContent: { padding: 12, paddingBottom: 32 },
  card: { borderRadius: 20, overflow: 'hidden', backgroundColor: theme.white, minHeight: 400 },
  yellow: { backgroundColor: theme.yellow, paddingVertical: 18, alignItems: 'center' },
  screenTitle: { fontSize: 18, fontWeight: '800', color: theme.black },
  loadingBox: { padding: 40, alignItems: 'center' },
  avatarRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 20, gap: 16 },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: theme.yellow,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarTxt: { fontSize: 22, fontWeight: '900', color: theme.black },
  avatarMeta: { flex: 1 },
  displayName: { fontSize: 22, fontWeight: '900', color: theme.text },
  memberSince: { fontSize: 13, color: theme.textMuted, fontWeight: '600', marginTop: 4 },
  planBanner: {
    marginHorizontal: 16,
    marginTop: 20,
    padding: 16,
    backgroundColor: theme.offWhite,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: theme.border,
  },
  planHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  planTitle: { fontSize: 14, fontWeight: '800', color: theme.textMuted, textTransform: 'uppercase', letterSpacing: 0.5 },
  planTier: { fontSize: 20, fontWeight: '900', color: theme.text, marginTop: 6 },
  planRenew: { fontSize: 14, color: theme.textMuted, marginTop: 6, fontWeight: '600', lineHeight: 20 },
  upgradeBannerBtn: {
    marginTop: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: theme.yellow,
    paddingVertical: 12,
    borderRadius: 14,
  },
  upgradeBannerBtnTxt: { fontSize: 15, fontWeight: '800', color: theme.black },
  sectionLabel: {
    fontSize: 12,
    fontWeight: '800',
    color: theme.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginTop: 24,
    marginBottom: 10,
    marginHorizontal: 20,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: theme.border,
  },
  detailTextWrap: { flex: 1 },
  detailMuted: { fontSize: 12, fontWeight: '700', color: theme.textMuted, marginBottom: 2 },
  detailValue: { fontSize: 16, fontWeight: '700', color: theme.text },
  detailValueMono: { fontSize: 12, fontWeight: '600', color: theme.text, fontFamily: Platform.select({ ios: 'Menlo', android: 'monospace' }) },
  upgradeOutline: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginHorizontal: 16,
    marginTop: 20,
    padding: 16,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: theme.black,
    backgroundColor: theme.white,
  },
  upgradeOutlineTxt: { flex: 1, fontSize: 16, fontWeight: '800', color: theme.black },
  outBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginHorizontal: 20,
    marginTop: 16,
    marginBottom: 24,
    backgroundColor: theme.yellow,
    paddingVertical: 14,
    borderRadius: 14,
  },
  outTxt: { fontSize: 16, fontWeight: '800', color: theme.black },
  fallback: { padding: 24, textAlign: 'center', color: theme.textMuted, fontWeight: '600' },
});
