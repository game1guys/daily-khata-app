import { Platform } from 'react-native';

/**
 * Base API URL. Android emulator: 10.0.2.2 → host. iOS Simulator: localhost. Physical device: set your machine LAN IP.
 */
export const API_URL =
  Platform.select({
    ios: 'http://localhost:5001/api',
    android: 'http://10.0.2.2:5001/api',
    default: 'http://10.0.2.2:5001/api',
  }) ?? 'http://10.0.2.2:5001/api';

/**
 * Must be the OAuth 2.0 Client of type "Web application" (used for ID tokens). Same project as Supabase Google auth.
 *
 * Android still needs a separate Credentials entry: OAuth client type "Android", package name `com.app`,
 * and the SHA-1 fingerprint of the keystore you build with (debug: run `./gradlew signingReport` in `android/`).
 * Without that Android client, Google shows "A non-recoverable sign in failure occurred" after picking an account.
 */
export const GOOGLE_WEB_CLIENT_ID = '1046778544158-r8r3dchf8dj490kijl1llnnijrqj0088.apps.googleusercontent.com';

/**
 * Public pricing / checkout page (web). Used by the app “Upgrade plan” flow (opens in browser).
 * Change to your production URL when deployed, e.g. https://yourdomain.com/pricing
 */
export const WEB_PRICING_URL =
  Platform.select({
    ios: 'http://localhost:5173/pricing',
    android: 'http://10.0.2.2:5173/pricing',
    default: 'http://10.0.2.2:5173/pricing',
  }) ?? 'http://10.0.2.2:5173/pricing';